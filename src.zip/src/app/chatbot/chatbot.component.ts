import { Component, ViewChild } from "@angular/core";
import { EcCbWindow } from "./window/window.component";
import { EcCbLaunch } from "./launch/launch.component";

@Component({
  selector: "ec-chatbot",
  templateUrl: "./chatbot.component.html",
  styleUrls: ["./chatbot.component.scss"]
})
export class EcChatbot {
  @ViewChild(EcCbWindow) window: EcCbWindow;
  @ViewChild(EcCbLaunch) launch: EcCbLaunch;

  showChatWindow = false;
  showLaunchIcon = true;

  // funtion to show and hide launch icon and chat window
  toggleChatLaunchAndWindow() {
    this.showLaunchIcon = !this.showLaunchIcon;
    this.showChatWindow = !this.showChatWindow;
  }
}
