// import { EcCbWindow } from './window.component';
// import { TestBed, async } from '@angular/core/testing';
// import { DataManagerService } from './data-manager.service';
// import { of } from 'rxjs';

// describe('EcCbWindow', ()=>{
//     let ecCbWindow: EcCbWindow;
//     beforeEach(() => TestBed.configureTestingModule({
//         providers: [DataManagerService]
//       }));

//     it("should call getUsers and return list of users", async(() => {
//         const response: User[] = [];
      
//         spyOn(DataManagerService, 'getData').and.returnValue(of(response));
        
      
//         // ecCbWindow.getUsers();
      
//         // fixture.detectChanges();
      
//         // expect(homeComponent.listOfUsers).toEqual(response);
//       }));
// })
