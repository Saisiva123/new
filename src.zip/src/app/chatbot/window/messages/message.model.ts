class Options {
  source:string;
  text: string;
  display: string;
  value: string;
  attr: string;
  next: string;
}

class Url {
  title: string;
  subtitle: string;
  url: string;
  thumbnail: string;
}

class Image {
  title: string;
  subtitle: string;
  url: string;
  thumbnail: string;
}
class Video {
  title: string;
  subtitle: string;
  url: string;
  thumbnail: string;
}
class Audio {
  title: string;
  subtitle: string;
  url: string;
  thumbnail: string;
}
class Document {
  title: string;
  subtitle: string;
  url: string;
  thumbnail: string;
}

class Next {
  true: string;
  false: string;
}

class Execute {
  proc: string;
  next: Next;
}

class Messsage {
  source: "";
  id: string;
  category: "";
  text: Array<"">;
  questions: Array<"">;
  answer: Array<"">;
  url: Url;
  image: Image;
  video: Video;
  audio: Audio;
  document: Document;
  options: Options;
  execute: Execute;
  next: String;
  isUseful: Boolean;
}

export { Options, Url, Image, Video, Audio, Document, Next, Execute, Messsage };
