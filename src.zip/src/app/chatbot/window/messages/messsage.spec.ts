import { Messsage } from './message.model';

describe('Messsage', () => {
  it('should create an instance', () => {
    expect(new Messsage()).toBeTruthy();
  });
});
