import { Component, Input, EventEmitter, Output, OnInit } from "@angular/core";

@Component({
  selector: "ec-cb-carousel",
  templateUrl: "./carousel.component.html",
  styleUrls: ["./carousel.component.scss"]
})
export class EcCbCarousel implements OnInit {
  @Input() carousel: Array<any> = [];
  @Output() emitMCarouselStatus = new EventEmitter<boolean>();

  ngOnInit() {}

  onEmitMSlideStatus(eve) {
    this.emitMCarouselStatus.emit(eve);
  }

  // scroll left on click of left arrow button
  scrollLeft(el: HTMLElement) {
    el.scrollLeft -= 162;
  }

  // scroll right on click of right arrow button
  scrollRight(el: HTMLElement) {
    el.scrollLeft += 162;
  }
}
