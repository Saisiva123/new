import { Component, Input, Output, EventEmitter, OnInit } from "@angular/core";
import { DataManagerService } from "../../../../shared/services/data.svc";
import { Options } from "../message.model";

@Component({
  selector: "ec-cb-button",
  templateUrl: "./button.component.html",
  styleUrls: ["./button.component.scss"]
})
export class EcCbButton implements OnInit {
  @Input() options: Array<"">;
  @Output() emitOptionOnMsg = new EventEmitter<{
    display: String;
    next: String;
  }>();
  public optionsData: Array<"">;

  constructor(private dataManagerService: DataManagerService) {}

  ngOnInit() {
    this.optionsData = this.options;
  }

  // on select option pass the selected object to message 
  onSelectOption(opt: Options) {
    opt.source = "UserResponse";
    this.emitOptionOnMsg.emit(opt);
  }
}
