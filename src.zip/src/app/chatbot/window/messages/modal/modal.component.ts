import { Component, Input, EventEmitter, Output, OnInit } from "@angular/core";
import { ConfigServcie } from "../../../../shared/services/config.svc";

@Component({
  selector: "ec-cb-modal",
  templateUrl: "./modal.component.html",
  styleUrls: ["./modal.component.scss"]
})
export class EcCbModal implements OnInit {
  content: any = {};
  @Output() emitModalClose = new EventEmitter<boolean>();
  @Input() modalData: any = {};
  modalDetailData: any = {};
  modalPriceData: any;
  constructor(private configServcie: ConfigServcie) {}

  ngOnInit() {
    this.content = this.configServcie.staticContent;
    if (this.modalData.type == "details") {
      this.modalDetailData = this.modalData.display.details;
    } else if (this.modalData.type == "price") {
      this.modalPriceData = this.modalData.display;
    }
  }

  // emit the close modal status to window
  onClickCloseModal() {
    this.emitModalClose.emit();
  }
}
