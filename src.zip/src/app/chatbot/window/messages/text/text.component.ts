import { Component, Input, OnInit } from "@angular/core";
import { UtilService } from "../../../../shared/services/util.svc";

@Component({
  selector: "ec-cb-text",
  templateUrl: "./text.component.html",
  styleUrls: ["./text.component.scss"]
})
export class EcCbText implements OnInit {
  public msgFromReciver = true;
  @Input() texts: Array<string>;
  public textData: any;
  speakerState = "unmute";
  canSpeak = false;
  text: any;
  constructor(private utilService: UtilService) {
    this.canSpeak = this.utilService.supportsSpeechSynthesis();
  }
  ngOnInit() {
    this.textData = this.texts;
  }
  speak(text) {
    this.speakerState = "mute";
    let audio = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(audio);
    audio.onend = function(event) {
      console.log(
        "Utterance has finished being spoken after " +
          event.elapsedTime +
          " milliseconds."
      );
      this.speakerState = "unmute";
    }.bind(this);
  }
  stopSpeaking() {
    //(window.speechSynthesis as any).stop();
    this.speakerState = "unmute";
  }
}
