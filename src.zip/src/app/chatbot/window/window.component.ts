import {
  Component,
  EventEmitter,
  Output,
  ViewChild,
  ElementRef,
  OnInit
} from "@angular/core";
import { DataManagerService } from "../../shared/services/data.svc";
import { ExcuteService } from "../../shared/services/excute.svc";
import { ConfigServcie } from "../../shared/services/config.svc";
import { EcCbMessages } from "./messages/messages.component";
import { UtilService } from "../../shared/services/util.svc";
import { WebcontainerinterfaceService } from "../../shared/services/webcontainerinterface.svc";
import io from "socket.io-client";

// creating model for option object
class OptionObj {
  public source: string;
  public text: Array<string>;
  // public display: string;
  // public value: string;
  // public attr: string;
  // public next: string;

  constructor(source?: string, text?: Array<string>) {
    //, display?: string, value?: string, attr?: string, next?: string) {
    this.source = source;
    this.text = text;
    // this.display = display;
    // this.value = value;
    // this.attr = attr;
    // this.next = next;
  }
}
// creating model for option object
class CarouselObj {
  public source: string;
  public carousel: Array<string>;

  constructor(source: string, carousel: Array<string>) {
    this.source = source;
    this.carousel = carousel;
  }
}

@Component({
  selector: "ec-cb-window",
  templateUrl: "./window.component.html",
  styleUrls: ["./window.component.scss"]
})
export class EcCbWindow implements OnInit {
  private socket;
  sai: string="sai";
  isTyping = true;
  public visibleChatWindow = false;
  initialId = "G1"; //"G1"; //
  chatObj: any;
  Messsage: Array<any> = [];
  Carousel: Array<any> = [];
  content: any = {};
  modalData: any = {};
  optionObj: OptionObj;
  carouselObj: CarouselObj;
  showModalBox = false;
  public innerWidth: any;
  showInputField = false;
  //private serverURL: string = "http://localhost:3002";


  @Output() emitLaunchIcon = new EventEmitter<boolean>();
  @ViewChild(EcCbMessages) msg: EcCbMessages;
  @ViewChild("messagesContainer") private messagesContainer: ElementRef;

  constructor(
    private dataManagerService: DataManagerService,
    private configServcie: ConfigServcie,
    private excuteService: ExcuteService,
    private utilService: UtilService,
    private webcontainerinterface:WebcontainerinterfaceService
  ) 
  {
    this.utilService.activeInputField.subscribe(data => {
      this.showInputField = data;
    });
  }

  ngOnInit() {
   //this.serverURL = this.configServcie.restapi.dataurl;
    
    //this.configServcie.restapi.dataurl.subscribe(data => {
    //  this.serverURL= data;
    //});
    this.socket = io.connect(this.configServcie.restapi.dataurl);
    this.chatObj = {
      next: this.initialId
    };
    // this.getChatTempData(this.initialId);
    this.reqMsg(this.initialId);
    this.content = this.configServcie.staticContent;
    this.innerWidth = window.innerWidth;
    this.excuteService.didYouMeanList.subscribe(observer => {
      this.Messsage.push({ didYouMeanList: observer });
    });
    this.showInputField = false;
    this.socket.on("resMsg", event => {
      this.chatObj = event.data;
      // console.log("getRandomSec()2", this.utilService.getRandomNumber(2000, 6000));
      setTimeout(
        function () {
          this.insertMessage();
        }.bind(this),
        this.utilService.getRandomNumber(2000, 6000)
      );
    });
  }

  // funtion to toggle visible and hide chat window
  launchChatWindow() {
    this.visibleChatWindow = !this.visibleChatWindow;
  }

  // funtion to toggle visible and hide chat window and emit launch icon to visible
  onClickClose() {
    this.emitLaunchIcon.emit();
    this.visibleChatWindow = !this.visibleChatWindow;
  }
call(event)
{
  this.webcontainerinterface.getData(event.text);

}
  // function initalize after while click on option
  // create the opject with option data and push into message array
  // if object has excute with next kery then it will call again get message function
  onEmitOptionOnWindow(msgObj) {
    this.isTyping=true;
    // let display = undefined;
    let text = undefined;
    if (msgObj.display) {
      text = Array.isArray(msgObj.display) ? msgObj.display : [msgObj.display];
    } else if (msgObj.text) {
      text = Array.isArray(msgObj.text) ? msgObj.text : [msgObj.text];
    }
    this.optionObj = new OptionObj(msgObj.source, text);
    this.Messsage.push(this.optionObj);
    if (msgObj.next) {
      // this.getChatTempData(msgObj.next);
      this.reqMsg(msgObj.next);
    } else if (msgObj.execute) {
      const result = this.excuteService[msgObj.execute.proc]();
      console.log("result", result);
      if (msgObj.execute.next) {
        // this.getChatTempData(msgObj.execute.next[result]);
        this.reqMsg(msgObj.execute.next[result]);
      }
    }
  }

  // function initailize after click on details button in slider
  onEmitMWindowStatus(eve) {
    this.showModalBox = !this.showModalBox;
    this.modalData = eve;
  }

  // function initailize after click on modal close button in slider
  onEmitModalClose() {
    this.showModalBox = !this.showModalBox;
  }

  // emit scroll if messgae is come
  onEmitMessageInited() {
    this.scrollDown();
  }

  // emit
  onEmitGotoID = this.reqMsg; //this.getChatTempData;

  /*  // temporary getting chat data
  getChatTempData(id) {
    setTimeout(() => {
      this.isTyping = true;
    }, 1000);

    // FOR USE AFTER DATA CONNECTIVITY
    this.dataManagerService.getData(id).subscribe((msg: any) => {
      this.chatObj = msg.data;
      console.log("getRandomSec()2", this.getRandomSec());
      setTimeout(insertMessage, this.getRandomSec());
    });
    // this.chatObj = this.dataManagerService.getTempData(id);

    const insertMessage = () => {
      this.isTyping = false;
      this.Messsage.push(this.chatObj);
      getNextMessage();
    };

    const getNextMessage = () => {
      if (this.chatObj && this.chatObj.next) {
        setTimeout(() => {
          this.isTyping = true;
        }, 1000);

        // FOR USE AFTER DATA CONNECTIVITY
        this.dataManagerService
          .getData(this.chatObj.next)
          .subscribe((msg: any) => {
            this.chatObj = msg.data;
            console.log(
              "getRandomSec()1",
              this.utilService.getRandomNumber(2000, 6000)
            );
            setTimeout(
              insertMessage,
              this.utilService.getRandomNumber(2000, 6000)
            );
          });
        // this.chatObj = this.dataManagerService.getTempData(this.chatObj.next);
        // setTimeout(insertMessage, this.utilService.getRandomNumber(2000, 6000));
      }
      if (this.chatObj && this.chatObj.execute) {
        if (this.chatObj.execute.proc) {
          //TODO: Remove from here...
          this.Carousel = this.dataManagerService.getCarouselData();
          this.carouselObj = new CarouselObj("UserResponse", this.Carousel);
          this.Messsage.push(this.carouselObj);

          const result = this.excuteService[this.chatObj.execute.proc]();
          console.log("result",result);
          
          if (this.chatObj.execute.next) {
            this.getChatTempData(this.chatObj.execute.next[result]);
          }
        }
      }
    };
    // REMOVE AFTER DATA CONNECTIVITY
    // setTimeout(insertMessage, this.utilService.getRandomNumber(2000, 6000));
  }*/

  // getRandomSec() {
  //   return Math.floor(Math.random() * (2000 - 6000)) + 6000;
  // }

  // function use to scroll down if data will come
  scrollDown() {
    if (this.messagesContainer) {
      this.messagesContainer.nativeElement.scrollTop = this.messagesContainer.nativeElement.scrollHeight;
    }
  }

  reqMsg(chatID) {
    this.socket.emit("reqMsg", chatID);
  }

  insertMessage = () => {
    this.isTyping = false;
    this.Messsage.push(this.chatObj);
    this.getNextMessage();
  };

  getNextMessage = () => {
    if (this.chatObj && this.chatObj.next) {
      setTimeout(() => {
        this.isTyping = true;
      }, 1000);

      // FOR USE AFTER DATA CONNECTIVITY
      this.reqMsg(this.chatObj.next);
      // this.chatObj = this.dataManagerService.getTempData(this.chatObj.next);
      // setTimeout(insertMessage, this.utilService.getRandomNumber(2000, 6000));
    }
    if (this.chatObj && this.chatObj.execute) {
      if (this.chatObj.execute.proc) {
        //TODO: Remove from here...
        this.Carousel = this.dataManagerService.getCarouselData();
        this.carouselObj = new CarouselObj("UserResponse", this.Carousel);
        this.Messsage.push(this.carouselObj);

        const result = this.excuteService[this.chatObj.execute.proc]();
        console.log("result", result);

        if (this.chatObj.execute.next) {
          this.reqMsg(this.chatObj.execute.next[result]);
        }
      }
    }
  };
}
