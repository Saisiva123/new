import {
	Component,
	EventEmitter,
	Output,
	ViewEncapsulation
} from "@angular/core";
import { DataManagerService } from "../../../../shared/services/data.svc";
import { ConfigServcie } from "../../../../shared/services/config.svc";
import io from "socket.io-client";
import { UtilService } from "../../../../shared/services/util.svc";
import * as _ from "lodash";

@Component({
	selector: "ec-cb-inputText",
	templateUrl: "./inputText.component.html",
	encapsulation: ViewEncapsulation.None,
	styleUrls: ["./inputText.component.scss"]
})
export class EcCbInputText {
	private socket;
	@Output() emitOptionOnWindow = new EventEmitter<boolean>();
	@Output() emitGotoID = new EventEmitter<string>();
	keyword: string = "_questions";
	question: string = "";
	questionList: any[];
	answers: object;
	isLoading: boolean = false;
	inputValue: string = "";
	voiceSearchActive = false;
	private serverURL: string = "http://localhost:3002/faq";
	canRecognitionSpeech: boolean = false;
	searchText:string ;
	speechRecognition: any;

	constructor(
		private dataManagerService: DataManagerService,
		private utilService: UtilService,
		private configservice: ConfigServcie
	) {
		this.searchText=this.configservice.string.data;
		
		// this.canRecognizeSpeech=this.utilService.supportsSpeechRecognition();
		this.socket = io.connect(this.serverURL);
		this.socket.on("typingRes", event => {
			this.isLoading = false;
			let list = _.map(event, "_source");
			console.log(list);
			// this.questionList = _.map(list, 'questions');	//event;
			// let a = [
			// 	{"title":["\"An unknown error occurred while accessing xxxx.rvt.\" in Revit"],"text":"While opening or synchronizing with the central file the following <span class=\"vivbold qt0\">error</span> is displayed:   \"An <span class=\"vivbold qt0\">unknown</span> <span class=\"vivbold qt0\">error</span> occurred while accessing xxxx.rvt\". Netw...","caas":"caas/sfdcarticles/sfdcarticles/Revit-Error-An-unknown-error-occurred-while-accessing-xxxx-rvt.html?st=unknown error","published":1567483200,"productPath":"/support/revit-products/","productSubNav":"troubleshooting/","thumbnail":"/sites/all/themes/autodesk_foundation5/images/search/default-thumbnail.png","source":"<img src=\"/sites/all/themes/autodesk_foundation5/images/standard/logo-mobile.png\" />Support","beehiveSource":"sfdcarticles","duration":null,"linkUrl":"http://help.autodesk.com.s3.amazonaws.com/sfdcarticles/Revit-Error-An-unknown-error-occurred-while-accessing-xxxx-rvt","userName":"","userPhoto":"","userEId":"","publicPath":"","redirectURL":null},
			// 	{"title":["Error: \"An unknown error occurred while MAXScript was performing garbage collection\" in 3ds Max"],"text":"During a normal use of 3ds Max, the following message periodically appears:   \"An <span class=\"vivbold qt0\">unknown</span> <span class=\"vivbold qt0\">error</span> occurred while MAXScript was performing garbage col...","caas":"caas/sfdcarticles/sfdcarticles/Error-An-unknown-error-occurred-while-MAXScript-was-performing-garbage-collection-in-3ds-Max.html?st=unknown error","published":1551589200,"productPath":"/search-result/","productSubNav":"","thumbnail":"/sites/all/themes/autodesk_foundation5/images/search/default-thumbnail.png","source":"<img src=\"/sites/all/themes/autodesk_foundation5/images/standard/logo-mobile.png\" />Support","beehiveSource":"sfdcarticles","duration":null,"linkUrl":"http://help.autodesk.com.s3.amazonaws.com/sfdcarticles/Error-An-unknown-error-occurred-while-MAXScript-was-performing-garbage-collection-in-3ds-Max","userName":"","userPhoto":"","userEId":"","publicPath":"","redirectURL":null},
			// 	{"title":["'Unknown error!' When installing an Autodesk product"],"text":"When installing your 2018 Autodesk product you notice it fails with <span class=\"vivbold qt0\">error</span> '<span class=\"vivbold qt0\">Unknown</span> <span class=\"vivbold qt0\">Error</span>!'    It is due to a corrupt installer or Internet connecti...","caas":"caas/sfdcarticles/sfdcarticles/Unknown-error-When-installing-an-Autodesk-product.html?st=unknown error","published":1537934400,"productPath":"/support/autocad/","productSubNav":"troubleshooting/","thumbnail":"/sites/all/themes/autodesk_foundation5/images/search/default-thumbnail.png","source":"<img src=\"/sites/all/themes/autodesk_foundation5/images/standard/logo-mobile.png\" />Support","beehiveSource":"sfdcarticles","duration":null,"linkUrl":"http://help.autodesk.com.s3.amazonaws.com/sfdcarticles/Unknown-error-When-installing-an-Autodesk-product","userName":"","userPhoto":"","userEId":"","publicPath":"","redirectURL":null},
			// 	{"title":["Backburner \"#17 Unknown Error\" when selecting connect button via Network Job Assignment window in 3ds Max"],"text":"Backburner \"#17 <span class=\"vivbold qt0\">Unknown</span> <span class=\"vivbold qt0\">Error</span>\" appears when selecting the connect button via the Network Job Assignment window in Autodesk® 3ds Max™. Net-rendering...","caas":"caas/sfdcarticles/sfdcarticles/Backburner-17-Unknown-Error-when-selecting-connect-button-via-Network-Job-Assignment-window-in-3ds-Max.html?st=unknown error","published":1492747200,"productPath":"/search-result/","productSubNav":"","thumbnail":"/sites/all/themes/autodesk_foundation5/images/search/default-thumbnail.png","source":"<img src=\"/sites/all/themes/autodesk_foundation5/images/standard/logo-mobile.png\" />Support","beehiveSource":"sfdcarticles","duration":null,"linkUrl":"http://help.autodesk.com.s3.amazonaws.com/sfdcarticles/Backburner-17-Unknown-Error-when-selecting-connect-button-via-Network-Job-Assignment-window-in-3ds-Max","userName":"","userPhoto":"","userEId":"","publicPath":"","redirectURL":null},
			// 	{"title":["Error: \"An unknown error has occurred while accessing an unnamed file\" while saving RTD file with Robot Structural Analysis"],"text":"While trying to save current RTD file, the following <span class=\"vivbold qt0\">error</span> appears: \"An <span class=\"vivbold qt0\">unknown</span> <span class=\"vivbold qt0\">error</span> has occurred while accessing an unnamed file\"   The possible ...","caas":"caas/sfdcarticles/sfdcarticles/ROBOT-Error-An-unknown-error-has-occurred-while-trying-to-access-a-file-with-no-name-while-saving-rtd-file.html?st=unknown error","published":1548306000,"productPath":"/search-result/","productSubNav":"","thumbnail":"/sites/all/themes/autodesk_foundation5/images/search/default-thumbnail.png","source":"<img src=\"/sites/all/themes/autodesk_foundation5/images/standard/logo-mobile.png\" />Support","beehiveSource":"sfdcarticles","duration":null,"linkUrl":"http://help.autodesk.com.s3.amazonaws.com/sfdcarticles/ROBOT-Error-An-unknown-error-has-occurred-while-trying-to-access-a-file-with-no-name-while-saving-rtd-file","userName":"","userPhoto":"","userEId":"","publicPath":"","redirectURL":null},
			// ];
			// list = _.map(list, function(obj:any) { obj._title = obj.title[0]; return obj;});
			// console.log(a);
			this.questionList = _.map(list, function(obj: any) {
				obj._questions = obj.questions[0];
				return obj;
			});
		});
		if ("webkitSpeechRecognition" in window) {
			this.speechRecognition = new (window as any).webkitSpeechRecognition();
		} else if ("SpeechRecognition" in window) {
			this.speechRecognition = new SpeechRecognition();
		}
		// this.utilService.supportsSpeechRecognition()
		// canRecognitionSpeech = true;
	}

	onSendClick(data?) {
		console.log(this.inputValue);
		this.onChangeSearch(this.inputValue);
	}
	selectEvent(selectedQuestion) {
		// this.dataManagerService.getAns(this.question).subscribe((data: any) => {
		// 	this.answers = data;
		// 	console.log("getAns() ", this.answers);
		// });
		let q = selectedQuestion.title;
		let a = selectedQuestion.text;
		a =
			a +
			`<br/><br/>The content is a little too large to read here hence, please <a href="${
				selectedQuestion.linkUrl
			}" target="_blank">read it here...</a>`;
		let opt: any = {
			source: "UserResponse",
			display: q
		};
		this.emitOptionOnWindow.emit(opt);
		opt = {
			source: "FAQ",
			text: a
		};
		this.emitOptionOnWindow.emit(opt);
		this.emitGotoID.emit("F2");
	}
	
	onChangeSearch(searchQuestion) {
		this.isLoading = true;
		this.socket.emit("typing", searchQuestion);
		// this.dataManagerService
		// 	.getAns(searchQuestion)
		// 	.subscribe((data: any) => {
		// 		this.isLoading = false;
		// 		this.questionList = data;
		// 		// console.log("getAns() ", this.answers);
		// 	});
	}
	onFocused(e) {
	this.isLoading=true;
		// this.dataManagerService.getAns(this.question).subscribe((data: any) => {
		// 	this.answers = data;
		// 	console.log("getAns() ", this.answers);
		// });
	}

	/*getList() {
		this.dataManagerService.getAns(this.question).subscribe((data: any) => {
			this.answers = data;
			let q = this.answers[0].title;
			let a = this.answers[0].text;
			a =
				a +
				`<br/><br/>The content is a little too large to read here hence, please <a href="${
					this.answers[0].linkUrl
				}" target="_blank">read it here...</a>`;
			let opt: any = {
				source: "UserResponse",
				display: q
			};
			this.emitOptionOnWindow.emit(opt);
			opt = {
				source: "FAQ",
				text: a
			};
			this.emitOptionOnWindow.emit(opt);
			this.emitGotoID.emit("F2");
			// this.answers.searchResults[0].title
			// this.answers.searchResults[0].text
			console.log("getAns() ", this.answers);
		});
	}*/

	toggleListening() {
	// this.searchText= "new test";
		if (this.voiceSearchActive) {
			this.voiceSearchActive = false;
			this.speechRecognition.stop();
		} else {
			this.startListening();
		}
	}
	startListening() {
		this.voiceSearchActive = true;
		this.speechRecognition.start();
		console.log("Listening to the user speak.");
		this.speechRecognition.onresult = function(event) {
			this.voiceSearchActive = false;
			var speech = event.results[0][0].transcript;
			// diagnostic.textContent = 'Result received: ' + color;
			console.log(speech);
			this.searchText = speech;
			// bg.style.backgroundColor = color;
		}.bind(this);
	}
}
