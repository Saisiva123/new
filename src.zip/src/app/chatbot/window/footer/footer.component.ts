import { Component, Output, EventEmitter } from "@angular/core";
import { UtilService } from "./../../../shared/services/util.svc";

@Component({
  selector: "ec-cb-footer",
  templateUrl: "./footer.component.html",
  styleUrls: ["./footer.component.scss"]
})
export class EcCFooter {
  @Output() emitOptionOnWindow = new EventEmitter<boolean>();
  @Output() emitGotoID = new EventEmitter<string>();
  showInputField = false;

  constructor(private utilService: UtilService) {
    this.utilService.activeInputField.subscribe(data => {
      this.showInputField = data;
    })    
  }

  ngOnInit() {
    this.showInputField = false;
  }

  onEmitOptionOnWindow(e) {
    this.emitOptionOnWindow.emit(e);
  }
  onEmitGotoID(e) {
    this.emitGotoID.emit(e);
  }
}
