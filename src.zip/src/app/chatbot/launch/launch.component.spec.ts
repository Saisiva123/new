import { EcCbLaunch } from './launch.component';
import { TestBed, async } from '@angular/core/testing';


describe('EcCbLaunch', () => {
    let ecCbLaunch: EcCbLaunch;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [EcCbLaunch]
        })
            .compileComponents();
        ecCbLaunch = new EcCbLaunch();
    }));

    xit('On click of launch icon hide the launch button', () => {
        const result = ecCbLaunch.onClickLaunch();
        expect(result).toBe(true);
    });
    xit('On click of chat window close button visible the launch button', () => {
        const result = ecCbLaunch.onClickLaunch();
        expect(result).toBe(false);
    });
});

