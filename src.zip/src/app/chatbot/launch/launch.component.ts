import { Component, EventEmitter, Output, Input, OnInit } from "@angular/core";
import { ConfigServcie } from "../../shared/services/config.svc";

@Component({
  selector: "ec-cb-launch",
  templateUrl: "./launch.component.html",
  styleUrls: ["./launch.component.scss"]
})
export class EcCbLaunch implements OnInit {
  public visibleLaunchIcon: boolean = false;
  @Output() emitChatWindow = new EventEmitter<boolean>();
  @Input() childMessage: string;
  content: any = {};

  constructor(private configServcie: ConfigServcie) {}

  ngOnInit() {
    this.content = this.configServcie.staticContent;
  }

  // function to emit data to window component and hide launch icon
  onClickLaunch() {
    this.emitChatWindow.emit();
    this.visibleLaunchIcon = !this.visibleLaunchIcon;
    return this.visibleLaunchIcon;
  }

  // function to visible icon
  visibleIcon() {
    this.visibleLaunchIcon = !this.visibleLaunchIcon;
    return this.visibleLaunchIcon;
  }
}
