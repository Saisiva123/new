import { BehaviorSubject } from "rxjs";

export class UtilService {
  private activeInputFieldBehavior = new BehaviorSubject<any>(false);
  activeInputField = this.activeInputFieldBehavior.asObservable();

  // activeInputFieldBehavior = false;
  getRandomNumber(from, to) {
    return Math.floor(Math.random() * (to - from + 1) + from);
  }

  constructor() {}

  setInputActive(status) {
    this.activeInputFieldBehavior.next(status);
  }
  supportsSpeechSynthesis = function() {
    return "speechSynthesis" in window;
  };
  supportsSpeechRecognition = function() {
    return "webkitSpeechRecognition" in window || "SpeechRecognition" in window;
  };
}
