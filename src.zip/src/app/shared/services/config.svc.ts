export class ConfigServcie {
    public staticContent = {
        text: {
            window: [],
            launch: ["I am Amdesia, <br />Come let's chat"]
        },
        images: {
            window: [
                "https://wpdev.eclerx.com:4502/angular/pwa/assets/img/mascotBlueBG.png",
                "https://wpdev.eclerx.com:4502/angular/pwa/assets/img/close.png"
            ],
            launch: ['https://wpdev.eclerx.com:4502/angular/pwa/assets/img/mascotBlackBG.png'],
            message: ['https://wpdev.eclerx.com:4502/angular/pwa/assets/img/mascotBlueBG.png']
        },
        url: {
            window: []
        }
    };
    public restapi =
        {
            dataurl: "http://localhost:3002"
        };
    public string=
    {
           data:"Enter the text here..."
    };
    public URLs = {
        shop: "https://www.amd.com/en/shop"
    };
}
