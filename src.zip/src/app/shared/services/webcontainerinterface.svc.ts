import { Injectable } from "@angular/core";

@Injectable({
  providedIn: 'root'
})
export class WebcontainerinterfaceService {

  constructor() { }
  getData(message)
  {

  }
}
