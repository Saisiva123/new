import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import {AutocompleteLibModule} from 'angular-ng-autocomplete';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { EcChatbot } from './chatbot/chatbot.component';
import { EcCbLaunch } from './chatbot/launch/launch.component';
import { EcCbWindow } from './chatbot/window/window.component';
import { EcCbMessages } from './chatbot/window/messages/messages.component';
import { EcCFooter } from './chatbot/window/footer/footer.component';
import { EcCbInputText } from './chatbot/window/footer/inputText/inputText.component';
import { EcCbDidYouMean } from './chatbot/window/messages/didYouMean/didYouMean.component';
import { EcCbButton } from './chatbot/window/messages/button/button.component';
import { EcCbText } from './chatbot/window/messages/text/text.component';
import { EcCbImage } from './chatbot/window/messages/image/image.component';
import { EcCbCarousel } from './chatbot/window/messages/carousel/carousel.component';
import { EcCbModal } from './chatbot/window/messages/modal/modal.component';
import { EcCbLink } from './chatbot/window/messages/link/link.component';
import { EcCbCarouselSlide } from './chatbot/window/messages/carousel/slide/slide.component';
import { DataManagerService } from './shared/services/data.svc';
import { ConfigServcie } from './shared/services/config.svc';
import { ExcuteService } from './shared/services/excute.svc';
import { UtilService } from './shared/services/util.svc';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

@NgModule({
  declarations: [
    AppComponent,
    EcChatbot,
    EcCbLaunch,
    EcCbWindow,
    EcCbMessages,
    EcCFooter,
    EcCbInputText,
    EcCbDidYouMean,
    EcCbButton,
    EcCbText,
    EcCbImage,
    EcCbModal,
    EcCbLink,
    EcCbCarousel,
    EcCbCarouselSlide,
  ],
  imports: [BrowserModule, AutocompleteLibModule, FormsModule,HttpClientModule, ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })],
  providers: [
    DataManagerService,
    HttpClient,
    ConfigServcie,
    ExcuteService,
    UtilService
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {}
